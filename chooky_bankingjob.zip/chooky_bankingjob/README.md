# ESX Banking - Sistema de Banca Corporativa by Ch00kyScripts

## Descripción

Sistema de banca avanzado para ESX Legacy que permite a jugadores con el job "bankero" gestionar cuentas bancarias, realizar transacciones y otorgar préstamos a otros jugadores.

## Características

- ✅ **Gestión de Cuentas**: Ver saldos de todos los jugadores
- ✅ **Transacciones**: Retirar y depositar dinero de cuentas bancarias
- ✅ **Sistema de Préstamos**: Otorgar préstamos con intereses y plazos
- ✅ **Logs de Transacciones**: Registro completo de todas las operaciones
- ✅ **Seguridad**: Sistema de permisos por grados y límites de transacciones
- ✅ **Interfaz Moderna**: UI intuitiva y responsive con temas claro/oscuro
- ✅ **Punto de Interacción**: Menú accesible en coordenadas específicas

## Requisitos

- **ESX Legacy** (1.8.5 o superior)
- **ox_lib** (para la interfaz)
- **oxmysql** (para la base de datos)

## Instalación

### 1. Descarga y Colocación

1. Descarga el script y colócalo en tu carpeta `resources`:
   ```
   resources/[esx]/esx_banking/
   ```

### 2. Configuración de la Base de Datos

El script creará automáticamente las tablas necesarias al iniciar:
- `banking_logs` - Registro de transacciones
- `banking_loans` - Gestión de préstamos

### 3. Configuración del Servidor

Asegúrate de que los siguientes recursos estén iniciados antes que `esx_banking`:
```
ensure es_extended
ensure ox_lib
ensure oxmysql
```

### 4. Iniciar el Script

Agrega a tu `server.cfg`:
```
ensure esx_banking
```

### 5. Configuración del Job

Asegúrate de tener el job "bankero" configurado en tu base de datos ESX:

```sql
INSERT INTO `jobs` (`name`, `label`) VALUES ('bankero', 'Banquero');

INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
('bankero', 0, 'employee', 'Empleado', 500, '{}', '{}'),
('bankero', 1, 'cashier', 'Cajero', 800, '{}', '{}'),
('bankero', 2, 'manager', 'Gerente', 1200, '{}', '{}'),
('bankero', 3, 'director', 'Director', 2000, '{}', '{}');
```

## Configuración

Edita el archivo `config.lua` para personalizar el sistema:

### Coordenadas
```lua
Config.BankingCoords = vector3(251.59, 222.91, 107.31) -- Ubicación del menú
```

### Permisos por Grado
```lua
Config.Grades = {
    [0] = { -- Empleado
        canView = true,
        canWithdraw = false,
        canDeposit = false,
        canGiveLoans = false,
        maxAmount = 0
    },
    [1] = { -- Cajero
        canView = true,
        canWithdraw = true,
        canDeposit = true,
        canGiveLoans = false,
        maxAmount = 10000
    },
    [2] = { -- Gerente
        canView = true,
        canWithdraw = true,
        canDeposit = true,
        canGiveLoans = true,
        maxAmount = 100000
    },
    [3] = { -- Director
        canView = true,
        canWithdraw = true,
        canDeposit = true,
        canGiveLoans = true,
        maxAmount = 1000000
    }
}
```

### Límites y Configuración de Préstamos
```lua
Config.MaxWithdraw = 1000000      -- Máximo para retirar
Config.MaxDeposit = 1000000       -- Máximo para depositar
Config.MaxLoan = 500000           -- Máximo para préstamos
Config.LoanInterest = 0.05        -- 5% de interés
Config.LoanDuration = 30          -- Días para pagar
Config.LoanPenalty = 0.1          -- 10% de penalización
```

## Uso

### Acceder al Sistema

1. **Ubicación física**: Ve a las coordenadas configuradas (251.59, 222.91, 107.31)
2. **Comando**: Usa `/banking` para abrir el menú
3. **Interacción**: Presiona `E` cerca del punto de interacción

### Funcionalidades

#### Gestión de Cuentas
- Ver todos los jugadores y sus saldos bancarios
- Buscar jugadores específicos
- Acceso a cuentas de jugadores online y offline

#### Transacciones
- **Retirar**: Sacar dinero de la cuenta bancaria de un jugador
- **Depositar**: Agregar dinero a la cuenta bancaria
- **Razón**: Todas las transacciones requieren una razón (se registra en logs)
- **Confirmación**: Transacciones grandes requieren confirmación adicional

#### Sistema de Préstamos
- **Otorgar Préstamos**: Dar dinero con interés y plazo definido
- **Monitorear**: Ver todos los préstamos activos
- **Marcar como Pagado**: Los préstamos pueden ser marcados como pagados
- **Intereses**: Cálculo automático de intereses

#### Logs del Sistema
- Todas las transacciones se registran automáticamente
- Información detallada: quién, cuándo, cuánto y por qué
- Compatible con Discord webhooks (configurable)

### Comandos

- `/banking` - Abre el menú de banca (solo para job "bankero")
- `/checkbank [id]` - Verificar cuenta de un jugador (comando admin)

## Seguridad

### Sistema de Permisos
- Permisos basados en grados del job "bankero"
- Límites máximos por grado
- Verificación de job antes de permitir acceso

### Prevención de Abuso
- Límite de transacciones por minuto (configurable)
- Confirmación requerida para transacciones grandes
- Registro completo de todas las operaciones

### Logs de Auditoría
- Todas las acciones se registran en la base de datos
- Información completa para auditorías
- Compatible con sistemas de logging externos

## Temas de Interfaz

El sistema incluye dos temas de interfaz:

### Tema Oscuro (por defecto)
- Colores oscuros y modernos
- Ideal para uso nocturno
- Contraste alto para mejor legibilidad

### Tema Claro
- Colores claros y limpios
- Ideal para uso diurno
- Menos fatiga visual en entornos brillantes

Para cambiar el tema, modifica en `config.lua`:
```lua
Config.UI = {
    Theme = 'light', -- 'dark' o 'light'
    -- ... otras configuraciones
}
```

## Soporte y Actualizaciones

### Solución de Problemas

**El menú no abre:**
1. Verifica que tengas el job "bankero"
2. Asegúrate de que el script esté iniciado
3. Revisa la consola del servidor por errores

**No puedo realizar transacciones:**
1. Verifica tu grado en el job "bankero"
2. Comprueba los límites en `config.lua`
3. Asegúrate de que el jugador objetivo exista

**Errores de base de datos:**
1. Verifica que `oxmysql` esté iniciado
2. Asegúrate de tener permisos para crear tablas
3. Revisa la configuración de conexión a la base de datos

### Personalización

Puedes personalizar:
- Colores de la interfaz editando `html/style.css`
- Textos y traducciones modificando los archivos Lua
- Límites y configuraciones en `config.lua`
- Añadir nuevas funcionalidades en los scripts

## Créditos

Desarrollado para ESX Legacy con las siguientes tecnologías:
- ESX Framework
- ox_lib (interfaz)
- Inter font family
- Font Awesome icons

## Licencia

Este script es gratuito para uso en servidores de FiveM.
Se permite la modificación y distribución con créditos al autor original.

---

**¡Disfruta del sistema de banca corporativa!** 💰🏦